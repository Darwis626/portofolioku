MINI PROJECT: LANDING PAGE PORTOFOLIO PRIBADI

Cara menjalankan:
1. Ekstrak file ZIP.
2. Buka folder portofolio-darwis.
3. Klik dua kali index.html, atau buka folder menggunakan VS Code lalu jalankan dengan Live Server.

Isi proyek:
- index.html: struktur halaman
- assets/style.css: styling dan responsive layout
- assets/script.js: menu burger, modal profil, dan validasi form
- assets/project-*.svg: ilustrasi lokal untuk tiga kartu proyek

Fitur sesuai tugas:
1. Navbar dengan menu burger + hero section + tombol CTA.
2. Grid 3 kartu proyek: 1 kolom di HP, 2 di tablet, 3 di desktop.
3. Form nama, email, pesan dengan validasi dan feedback.
4. Tombol yang membuka modal profil/ruang sertifikat.

Catatan:
- Formulir menggunakan validasi sisi klien saja, belum mengirim data ke server.
- Konten proyek dan profil dapat diedit langsung di index.html.
- Sertifikat tidak dibuat-buat; area sertifikat pada modal disiapkan untuk diisi bila sudah ada.
- Font Google akan dimuat bila perangkat terhubung ke internet; halaman tetap menggunakan fallback font saat offline.

Deploy GitHub Pages:
1. Buat repository baru di GitHub.
2. Upload index.html dan folder assets (bukan hanya file ZIP-nya).
3. Buka Settings > Pages, pilih branch utama dan folder root, lalu Save.
4. Tunggu GitHub Pages menerbitkan alamat situs.
