(() => {
  'use strict';

  const menuToggle = document.getElementById('menuToggle');
  const navLinks = document.getElementById('navLinks');
  const modalBackdrop = document.getElementById('profileModal');
  const modal = modalBackdrop.querySelector('.profile-modal');
  const modalClose = modalBackdrop.querySelector('.modal-close');
  const modalDone = modalBackdrop.querySelector('.modal-done');
  const form = document.getElementById('contactForm');
  const feedback = document.getElementById('formFeedback');
  let lastFocusedElement = null;

  // Navigasi burger untuk layar kecil.
  menuToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Tutup menu navigasi' : 'Buka menu navigasi');
  });

  navLinks.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
      menuToggle.setAttribute('aria-label', 'Buka menu navigasi');
    });
  });

  // Dialog profil/sertifikat dengan dukungan tombol Escape dan fokus.
  function openModal() {
    lastFocusedElement = document.activeElement;
    modalBackdrop.hidden = false;
    document.body.style.overflow = 'hidden';
    modal.focus();
    modalClose.focus();
  }

  function closeModal() {
    modalBackdrop.hidden = true;
    document.body.style.overflow = '';
    if (lastFocusedElement && typeof lastFocusedElement.focus === 'function') {
      lastFocusedElement.focus();
    }
  }

  document.querySelectorAll('[data-open-modal]').forEach((button) => {
    button.addEventListener('click', openModal);
  });
  modalClose.addEventListener('click', closeModal);
  modalDone.addEventListener('click', closeModal);
  modalBackdrop.addEventListener('click', (event) => {
    if (event.target === modalBackdrop) closeModal();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !modalBackdrop.hidden) closeModal();
  });

  // Validasi form sisi klien; tidak mengirim data ke server.
  const fields = {
    name: {
      input: document.getElementById('name'),
      error: document.getElementById('nameError'),
      validate(value) {
        if (!value.trim()) return 'Nama wajib diisi.';
        if (value.trim().length < 2) return 'Nama minimal terdiri dari 2 karakter.';
        return '';
      }
    },
    email: {
      input: document.getElementById('email'),
      error: document.getElementById('emailError'),
      validate(value) {
        if (!value.trim()) return 'Alamat email wajib diisi.';
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
        return emailPattern.test(value.trim()) ? '' : 'Masukkan alamat email yang valid.';
      }
    },
    message: {
      input: document.getElementById('message'),
      error: document.getElementById('messageError'),
      validate(value) {
        if (!value.trim()) return 'Pesan wajib diisi.';
        if (value.trim().length < 10) return 'Pesan minimal terdiri dari 10 karakter.';
        return '';
      }
    }
  };

  function validateField(field) {
    const message = field.validate(field.input.value);
    field.error.textContent = message;
    field.input.setAttribute('aria-invalid', String(Boolean(message)));
    return !message;
  }

  Object.values(fields).forEach((field) => {
    field.input.addEventListener('blur', () => validateField(field));
    field.input.addEventListener('input', () => {
      if (field.input.hasAttribute('aria-invalid')) validateField(field);
      feedback.className = 'form-feedback';
      feedback.textContent = '';
    });
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const isValid = Object.values(fields).map(validateField).every(Boolean);

    if (!isValid) {
      feedback.textContent = 'Periksa kembali kolom yang ditandai, lalu coba lagi.';
      feedback.className = 'form-feedback visible error';
      const firstInvalid = Object.values(fields).find((field) => field.input.getAttribute('aria-invalid') === 'true');
      if (firstInvalid) firstInvalid.input.focus();
      return;
    }

    const senderName = fields.name.input.value.trim();
    feedback.textContent = `Terima kasih, ${senderName}! Semua kolom valid. Ini adalah demo validasi; pesan belum dikirim ke server.`;
    feedback.className = 'form-feedback visible success';
    form.reset();
    Object.values(fields).forEach((field) => {
      field.error.textContent = '';
      field.input.removeAttribute('aria-invalid');
    });
  });

  document.getElementById('year').textContent = String(new Date().getFullYear());
})();
